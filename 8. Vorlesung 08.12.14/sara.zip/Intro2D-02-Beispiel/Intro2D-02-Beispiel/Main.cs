﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Window;
using SFML.Graphics;

namespace Intro2D_02_Beispiel
{
    class Game
    {
        public static void Main()
        {

            RenderWindow win = new RenderWindow(new VideoMode(800, 600), "Mein zweites Fenster");
            GameTime time = new GameTime();
            time.start();
            win.Closed += win_Closed;

            while (win.IsOpen())
            {
                win.DispatchEvents();
                time.update();
                update(time);
                draw(win);
            }
        }


        public static void initialize()
        {

        }
        public static void loadContent()
        {

        }
        public static void update(GameTime time)
        {

        }
        public static void draw(RenderWindow win)
        {
            //AcaOrange new Color(255, 144, 1)
            //Cornflower blue new Color(101, 156, 239)
            win.Clear(new Color(255, 144, 1));

            win.Display();
        }


        static void win_Closed(object sender, EventArgs e)
        {
            ((RenderWindow) sender).Close();
        }
    }
}
