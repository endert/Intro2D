﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intro2D_08_Beispiel
{
    class Program
    {
        static void Main(string[] args)
        {
            Game g = new Game();
            g.Run();
        }
    }
}
